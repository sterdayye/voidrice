find . -maxdepth 1 -regextype gnu-awk -regex "^.*\.(pyc|p    yo|bak|swp|aux|log|lof|nav|out|snm|toc|bcf|run\.xml|synctex\.gz|blg|bbl)" -delete
